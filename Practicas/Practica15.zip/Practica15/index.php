<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Practica 15(9)</title>
</head>
<body>
    <h2>Insertar</h2>
    <form action="insertar.php" method="POST">
        <input type="text" name="nombre" placeholder="Nombre" required><br>
        <input type="number" name="edad" placeholder="Edad" required><br>
        <input type="text" name="correo" placeholder="Correo" required><br>
        <input type="submit" value="Insertar">
        <input type="reset" value="Borrar">
    </form>
</body>
</html>